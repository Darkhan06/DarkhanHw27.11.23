import java.time.DayOfWeek;
import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        // 1 уровень сложности: Задание 1
        //Напиши программу, которая моделирует ситуацию.
        //Ты попросил(а) друзей скинуться на подарок на твой День Рождения.
        // Каждый друг случайным образом может подарить тебе одну купюру номиналом 50, 100, 200 или 500 долларов.
        // Твоя цель - новенький игровой компьютер, который стоит 10 000 долларов.
        //Как только друзья подарят тебе нужную сумму (или даже чуть больше),
        // останавливай сбор подарков и веди всех выпить за твоё здоровье в лучший бар города!
        int amountBills = 0;

        while (amountBills<=10000){
            Random r = new Random();
            int сhoiceBills = r.nextInt(4);
            int bills = switch (сhoiceBills){
                case 0 -> 50;
                case 1 -> 100;
                case 2 -> 200;
                case 3 -> 500;
                default -> 404;
            };
            amountBills += bills;
            System.out.println(amountBills);

        }
        //Задание 2
        //Используйте for для вычисления суммы.
        //Используйте do-while для организации повторения программы.
        //
        //Необходимо суммировать все нечётные целые числа в диапазоне, введённом пользователем.
        // Программу повторять, пока пользователь не введёт «quit».

        Scanner sc = new Scanner(System.in);
        System.out.println("Введите первое число");
        int num1 = sc.nextInt();
        System.out.println("Введите второе число");
        int num2 = sc.nextInt();
        int max = Math.max(num1,num2);
        int min = Math.min(num1,num2);
        String user = "";


       do {
           int sum = 0;
           System.out.println("Диапазон");
           for (int i = min; i <= max; ++i) {
               System.out.println(i % 2 != 0 ? 0 : ++i);
               sum = sum + i;
           }
           System.out.println("Сумма =" + sum);
           System.out.println("Введите quit ");
           user = sc.nextLine();
       }
       while (!user.equalsIgnoreCase("quit"));

        //Задание 3
        //Используйте foreach.
        //Дан Enum дней недели. Пользователь вводит имя текущего дня в консоль.
        // Программа должна вывести все дни недели, кроме данного.
        System.out.println("Day");
        String userDay = sc.nextLine();
        DayOfWeek i = DayOfWeek.valueOf(userDay.trim().toUpperCase());

        for (DayOfWeek day : DayOfWeek.values()) {
            if (day != i) System.out.println(day);
        }
    }

}
